define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./applescript.snippets");
exports.scope = "applescript";

});
