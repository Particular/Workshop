define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./forth.snippets");
exports.scope = "forth";

});
